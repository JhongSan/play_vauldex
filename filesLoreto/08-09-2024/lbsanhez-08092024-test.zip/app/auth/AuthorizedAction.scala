import play.api.mvc._
import javax.inject._
import scala.concurrent.{ Future, ExecutionContext }

class AuthorizedAction @Inject() (parser: BodyParsers.Default)(implicit ec: ExecutionContext)
    extends ActionBuilderImpl(parser) {
  override def invokeBlock[A](request: Request[A], block: (Request[A]) => Future[Result]) = {
    //logger.info("Calling action")
    block(request)
  }
}