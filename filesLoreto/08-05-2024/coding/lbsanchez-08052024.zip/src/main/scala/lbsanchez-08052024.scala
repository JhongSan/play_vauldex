import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{Failure, Success}

def f1: Future[Int] = Future(1)
def f2: Future[Option[Int]] = Future.successful(Some(10))
def f3: Future[Option[Int]] = Future.successful(None)
def f4: Future[Seq[Int]] = Future.successful(1 to 10)
def f5: Future[Seq[Int]] = Future.successful(Nil)
def f6: Future[Option[Seq[Int]]] = Future.successful(Some(1 to 10))
def f7: Future[Option[Seq[Int]]] = Future.successful(None)
def f8: Future[Seq[Option[Int]]] = Future.successful(Seq(Some(100), Some(1000), None))
def f9: Future[Option[Future[Int]]] = Future.successful(Some(Future.successful(1)))
def f10: Future[Seq[Future[Int]]] = Future.successful((1 to 10).map(Future.successful))

@main def test =
  // #1 Get the result of f1 + f2
  val F1 = for r1 <- f1 yield r1
  val F2 = for r2 <- f2 yield r2
  val ff2 = F2.onComplete{
    case Success(x) => x
    case Failure(x) => x.printStackTrace
  }
  val ff1 = F1.onComplete{
      case Success(y) => y
      case Failure(y) => y.printStackTrace
  }
  // #2: Get the result of f1 + f2 + f3
  val F3 = for r3 <- f3 yield r3
  val ff3 = F3.onComplete{
    case Success(x) => x
    case Failure(x) => x.printStackTrace
  }
  // #3: Get sum total of f4
  val F4 = for r4 <- f4 yield r4
  val ff4 = F4.onComplete{
    case Success(x) => x.sum
    case Failure(x) => x.printStackTrace
  }
  // #4: Get sum total of f4 and f5

  // #5 Transform f4 to `Future[Seq[Int], Seq[Int]]` as `Future((Range 1 to 5, Range 6 to 10))`