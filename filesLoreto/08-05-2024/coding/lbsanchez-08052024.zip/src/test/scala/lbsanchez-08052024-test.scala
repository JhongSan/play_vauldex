import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class FutureSpec extends AnyFlatSpec:
  "Number 1" should "return the result" in {
    val F1 = for r1 <- f1 yield r1
    val F2 = for r2 <- f2 yield r2
    val ff2 = F2.onComplete{
    case Success(x) => x
    case Failure(x) => x.printStackTrace
    }
    val ff1 = F1.onComplete{
      case Success(y) => y
      case Failure(y) => y.printStackTrace
    }
    ff1 + ff2 shouldBe 11
  } 

  "Number 2" should "return the result" in {
    val F1 = for r1 <- f1 yield r1
    val F2 = for r2 <- f2 yield r2
    val ff2 = F2.onComplete{
    case Success(x) => x
    case Failure(x) => x.printStackTrace
    }
    val ff1 = F1.onComplete{
      case Success(y) => y
      case Failure(y) => y.printStackTrace
    }
    val F3 = for r3 <- f3 yield r3
    val ff3 = F3.onComplete{
      case Success(x) => x
      case Failure(x) => x.printStackTrace
    }
    ff1 + ff2 + ff3 shouldBe 11
  }

  "Number 3" should "return the result" in {
    val F4 = for r4 <- f4 yield r4
    val ff4 = F4.onComplete{
        case Success(x) => x.sum
        case Failure(x) => x.printStackTrace
    }
  }

  "Number 4" should "return the result" in {
    Future(f4).map(_).sum + Future(f5).map(_) shouldBe 55
  }

  "Number 5" should "transform the the given method" in {
    f5 shouldBe Future.successful(1 to 5, 6 to 10)
  }