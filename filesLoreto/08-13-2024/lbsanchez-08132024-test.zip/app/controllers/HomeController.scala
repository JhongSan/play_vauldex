package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import models.User
import play.api.data._
import play.api.data.Forms._

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(val controllerComponents: ControllerComponents) extends BaseController {

  /**
   * Create an Action to render an HTML page.
   *
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }

  val userForm = Form(
    mapping(
      "id" -> text,
      "email"  -> text,
      "username" -> text(100),
      "password" -> text(8, 250)
    )(User.apply)(User.unapply)
  )

  def createUser = Action { implicit request =>
    userForm.bindFormRequest().
      fold(
        formWithErrors => {
          BadRequest
        },
        userData => {
          val newUser = models.User(userData.id, userData.email, userData.username, userData.password)
          vad id = models.User.create(newUser)
          Ok
        }
      )
    }
  }
}
