package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import models._
import play.api.data._
import play.api.data.Forms._

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(val controllerComponents: ControllerComponents) extends BaseController {

  /**
   * Create an Action to render an HTML page.
   *
   * The configuration in the `routes` file means that this method
   * will be called when the application receives a `GET` request with
   * a path of `/`.
   */
  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index())
  }

  def login = Action { implicit request =>  
    Ok(views.html.user())
  }
  def validateLoginGet(username: String, password: String) = Action {
    Ok(s"$username you have logged in.")
  }

  val userForm = Form(
    mapping(
      "id" -> text,
      "email"  -> text,
      "username" -> text(max(100)),
      "password" -> text(min(8), max(250))
    )(User.apply)(User.unapply)
  )

  val profileForm = Form(
    mapping(
      "id" -> text,
      "firstName"  -> text,
      "middleName" -> optional(max(250)),
      "lastName" -> text(max(250))
    )(User.apply)(User.unapply)
  )

  def createUser = Action { implicit request =>
    userForm.bindFormRequest().
      fold(
        formWithErrors => {
          BadRequest(views.html.user(formWithErrors))
        },
        userData => {
          val newUser = models.User(userData.id, userData.email, userData.username, userData.password)
          vad id = models.User.create(newUser)
          Ok
        }
      )
    }
  }

  def createProfile = Action { implicit request =>
    profileForm.bindFormRequest().
      fold(
        formWithErrors => {
          BadRequest(views.html.user(formWithErrors))
        },
        userData => {
          val newUser = models.User(userData.id, userData.email, userData.username, userData.password)
          vad id = models.User.create(newUser)
          Ok
        }
      )
    }
  }
}
