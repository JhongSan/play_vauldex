package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import play.api.libs.json
import java.util.UUID

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class ActionController @Inject()(val controllerComponents: ControllerComponents) extends BaseController {
  def action1 = Action {
    Ok("Hello World")
  }

  def action2 = Action {
    Ok(<html>HTML</html>).as("application/html")
  }

  def action3 = Action {
    Ok(<html>HTML</html>).as("text/html")
  }

  def action4 = Action {
    Ok(<html>
      <head>
        <title> Hello World</title>
      </head>
      <body>
        <h1>Hello World</h1>
      </body>
    </html>).as("text/html")
  }

  def action5 = Action { implicit request: Request[AnyContent] =>
    val remote = request.remoteAddress
    Ok(remote)
  }

  def action6 = Action { implicit request: Request[AnyContent] =>
    request.body.asJson.map{ json =>
      Ok(json)
    }.getOrElse(Ok("No Json Body"))
  }

  case class User(id: Int, name: String)
  def findUserById(id: Int): Future[Option[User]] = {
    val users = List(
      User(1, "John"),
      User(2, "William"),
      User(3, "James"),
      User(4, "Michael"),
      User(5, "Robert"),
      User(6, "David"),
      User(7, "Thomas"),
      User(8, "Charles"),
      User(9, "George"),
      User(10, "Joseph"))
    Future.successful(users.find(_.id == id))
}

  def action7(userId: Int) = Action { implicit request: Request[AnyContent] =>
    if(findUserById(user) == Future.successful){
      Ok
    }
    else{
      Ok("Not Found")
    }
  }

}
